package me.cordeiro.TPSign;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;

//import java.net.http.WebSocket.Listener;
import java.time.Duration;
import java.util.List;

import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.java.JavaPlugin;


public class tpsign extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("TPSign plugin ativado!!!!!!!!");
    }

    private Component colorir(String texto) {
    return Component.text(
        org.bukkit.ChatColor.translateAlternateColorCodes('&', texto));
    }

    @EventHandler
    public void aoClicar(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;

        if (!(e.getClickedBlock().getState() instanceof Sign)) return;

    Player p = e.getPlayer();
    Sign sign = (Sign) e.getClickedBlock().getState();

    String linha1 = sign.getLine(0);
    String linha3 = sign.getLine(2);

        if (linha1.equalsIgnoreCase("[Minigame]")) {
            World mundo = Bukkit.getWorld(linha3);

            if (mundo == null) {
                p.sendMessage("§cMundo não encontrado!");
                return;
            }

            p.teleport(mundo.getSpawnLocation());
            p.sendMessage("§aTeleportado para " + linha3);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if(!(sender instanceof Player)) return true;
        Player p = (Player) sender;

        if (command.getName().equalsIgnoreCase("lobby")) {
            
            World lobby = Bukkit.getWorld(getConfig().getString("lobby"));

            if (lobby == null) {
                p.sendMessage("§cMundo do lobby não encontrado!");
                return true;
            }

            if(p.getWorld().getName().equals(lobby.getName())) {
                p.sendMessage("§cVocê já está no lobby!");
                return true;
            }

            p.teleport(lobby.getSpawnLocation());
            p.sendMessage("§aLOBBY!");
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }



        return true;
    }

}