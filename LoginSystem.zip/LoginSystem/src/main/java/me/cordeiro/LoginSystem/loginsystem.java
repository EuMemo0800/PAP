package me.cordeiro.LoginSystem;

import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.inject.Named;

import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;

public class loginsystem extends JavaPlugin implements Listener {
    private Set<UUID> jogadoresLogados = new HashSet<>();   // Conjunto para armazenar os jogadores que estão logados

    @Override       // Método chamado quando o plugin é ativado
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);   // Registra os eventos do plugin
        getLogger().info("SISTEMA DE LOGIN LIGADO!!!!!!!!!!");
    }

    @EventHandler      // Evento chamado quando um jogador entra no servidor
    public void aoEntrar(PlayerJoinEvent e) {   //Metodo aoEntrar que pede para o jogador se registrar ou fazer login
        Player p = e.getPlayer();   // Pega o jogador que entrou no servidor
        String lobbyName = getConfig().getString("lobby"); // Pega o nome do mundo do lobby do config.yml
        
        World lobby = Bukkit.getWorld(lobbyName); // Pega o mundo do lobby

        Bukkit.getScheduler().runTaskTimer(this, task -> {
        
        p.teleport(lobby.getSpawnLocation()); // Teleporta o jogador para o spawn do mundo
        
        if(!p.isOnline()) {   // Se o jogador sair do servidor, para o loop
            task.cancel();
            return;
        }

        // Se o jogador já estiver logado, para o loop
        if (jogadoresLogados.contains(p.getUniqueId())) {
            task.cancel();
            return;
        }

        if (!temSenha(p)) {
            p.sendMessage("§eUse /register <senha>");

            p.showTitle(Title.title(
                Component.text("Bem-vindo!").color(NamedTextColor.GREEN),
                Component.text("Use /register <senha>"),
                Title.Times.times(
                    Duration.ofMillis(500),
                    Duration.ofSeconds(3),
                    Duration.ofMillis(500)
                )
            ));

        } else {
            p.sendMessage("§eUse /login <senha>");

            p.showTitle(Title.title(
                Component.text("Bem-vindo!").color(NamedTextColor.GREEN),
                Component.text("Use /login <senha>"),
                Title.Times.times(
                    Duration.ofMillis(500),
                    Duration.ofSeconds(3),
                    Duration.ofMillis(500)
                )
            ));
        }

    }, 0L, 100L); // 100 ticks = 5 segundos
}

    @EventHandler
    public void aoSair(PlayerQuitEvent e) {   //Metodo aoSair que remove o jogador do conjunto de jogadores logados quando ele sair
        Player p = e.getPlayer();   // Pega o jogador que saiu do servidor
        jogadoresLogados.remove(p.getUniqueId());    // Remove o jogador do conjunto de jogadores logados
    }



    @EventHandler   // Evento chamado quando um jogador tenta se mover
    public void aoMover(PlayerMoveEvent e) {    //Classe aoMover que impede o jogador de se mover se nao estiver logado
        Player p = e.getPlayer();   // Pega o jogador que tentou se mover

        if (!jogadoresLogados.contains(p.getUniqueId())) {  // Se o jogador nao estiver logado
            e.setCancelled(true);   // Cancela o movimento do jogador
        }
    }

    @EventHandler
    public void aoUsarCommando(PlayerCommandPreprocessEvent e){  //metodo aoUsarComando que impede o jogador de usar comandos se nao estiver logado
        Player p = e.getPlayer();
        if (!jogadoresLogados.contains(p.getUniqueId())) {  // Se o jogador nao estiver logado
            if (!e.getMessage().startsWith("/login") && !e.getMessage().startsWith("/register")) {  // Se o comando nao for /login ou /register
                p.sendMessage("§cPrecisas fazer login para utilizar esse comando."); //diz que precisa fazer login
                e.setCancelled(true);   // Cancela o comando
            }
        }
    }

    private boolean temSenha(Player p){     //Metodo que verifica se o jogador tem senha
        return getConfig().contains("jogadores." + p.getUniqueId());    // Verifica se o jogador tem senha no arquivo config.yml
    }

    private String getSenha(Player p) {   //Metodo que pega a senha do jogador
    return getConfig().getString("jogadores." + p.getUniqueId() + ".senha");    // Pega a senha do jogador no arquivo config.yml
    }

    private void setSenha(Player p, String senha) {  //Metodo que seta a senha do jogador
    getConfig().set("jogadores." + p.getUniqueId() + ".senha", senha);  // Salva a senha do jogador no arquivo config.yml
    saveConfig();   // Salva o arquivo config.yml
    }
    
    
    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if(!(sender instanceof Player)) return true;    // Verifica se o comando foi executado por um jogador
        Player p = (Player) sender;  // Pega o jogador que executou o comando

        if(command.getName().equalsIgnoreCase("login")) {   // Comando /login
            if(args.length != 1) {  // Verifica se o jogador passou a senha como argumento
                p.sendMessage("§cUse /login <senha>");
                return true;
            }

            if(!temSenha(p)) {  // Verifica se o jogador nao esta registrado
                p.sendMessage("§cVoce ainda nao esta registrado!");
                p.sendMessage("§eUse /register <senha>");
                return true;
            }

            String senha = args[0]; // Pega a senha passada como argumento
            if(senha.equals(getSenha(p))) { // Verifica se a senha esta correta
                jogadoresLogados.add(p.getUniqueId());  // Adiciona o jogador ao conjunto de jogadores logados
                p.sendMessage("§aLogin efetuado");
                return true;
            } else {    // Se a senha estiver incorreta
                p.sendMessage("§cSenha incorreta!");
                return true;
            }
        }

        if(command.getName().equalsIgnoreCase("register")) {    // Comando /register
            if(args.length != 1) {  // Verifica se o jogador passou a senha como argumento
                p.sendMessage("§cUso correto: /register <senha>");
                return true;
            }

            if(temSenha(p)) {   // Verifica se o jogador ja esta registrado
                p.sendMessage("§cVoce ja esta registrado!");
                return true;
            }

            String senha = args[0]; // Pega a senha passada como argumento
            setSenha(p, senha); // Salva a senha do jogador
            jogadoresLogados.add(p.getUniqueId());  // Adiciona o jogador ao conjunto de jogadores logados
            p.sendMessage("§aRegistrado com sucesso!");
            return true;
        }


    return false;
    }
}